public interface Fly {

    public void fly();
}
