public interface Run {

    public void run();
}
