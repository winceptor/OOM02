public interface Shout {

    public void shout(String shout);
}
