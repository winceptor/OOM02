public class Mainclass {

    public static void main(String[] args) {
        Zoo newZoo = new Zoo();
        
        Bird newBird = new Bird();
        Cage newCage1 = new Cage(newBird);
        newZoo.addCage(newCage1);
        newBird.fly();
        
        Horse newHorse = new Horse();
        Cage newCage2 = new Cage(newHorse);
        newZoo.addCage(newCage2);
        newHorse.run();
        
        Pegasus newPegasus = new Pegasus();
        Cage newCage3 = new Cage(newPegasus);
        newZoo.addCage(newCage3);
        newPegasus.fly();
        newPegasus.run();
        
        Cage cage2 = newZoo.checkCage(2);
        cage2.getAnimal();
        
        Cage pegasusCage = newZoo.findCage("Pegasus");
        if (pegasusCage!=null)
        {
            pegasusCage.feedAnimal();
        }
        
        Animal happyBird;
        happyBird = newZoo.findCage("Bird").getAnimal();
        happyBird.nameAnimal("Happy");
        
                
        Griffin newGriffin = new Griffin();
        Cage newCage4 = new Cage(newGriffin);
        newZoo.addCage(newCage4);
        
        newGriffin.fly();
        newGriffin.run();
        newGriffin.shout("Roar!");
  
    }
}
